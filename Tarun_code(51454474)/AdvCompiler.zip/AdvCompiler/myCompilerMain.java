/**
*this is a mini compiler
*@author Tarun Sikka
*/
import java.util.*;
import java.io.*;
public class myCompilerMain{
	public static void main(String args[])throws Exception
	{
		File file=new File(args[0]); 
		lineCount lc=lineCount.getInstance();
        lc.convertForCount(file);
	}
}