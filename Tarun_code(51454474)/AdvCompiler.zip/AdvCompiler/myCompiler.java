import java.io.*;
import java.util.*;
public abstract class myCompiler
{
	String convertForKeyword(String st)throws Exception{
		return "To replace keywords";
	}
	void convertForCount(File sent)throws Exception{}
}