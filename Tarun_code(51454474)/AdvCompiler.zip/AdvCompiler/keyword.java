import java.io.*;
import java.util.*;
import java.util.concurrent.*;
public class keyword extends myCompiler
{
	ConcurrentHashMap<String,String> map= new ConcurrentHashMap<>();
	String ar[],fi, var[], mk, value, mvalue,load;
	int ctri=1,ctrf=1,ctrs=1,ctro=1;
    //to replace keywords in a string
	public String convertForKeyword(String str)throws Exception
	{
				//split line by space
				ar=str.split(" ");
				//fi -> final string
		        fi="";
		        //load stores iload, fload lines
		        load="";
		        //check tokens 
		        for(int i=0;i<ar.length;i++)
		        {
		        	if(ar[i].equals("int"))
		        	{		
		        			ar[i]="i_store";
		        			fi=ar[i];
		        			i++;
		        			
		        			var=ar[i].split("[,;]");
		        			//System.out.println(Arrays.toString(var));
		        			for(int x=0;x<var.length;x++)
		        			{
		        					if(var[x].contains("="))
		        					{
		        						mk=var[x].substring(0,var[x].indexOf('='));
		        						value= var[x].substring(var[x].indexOf('=')+1);
		        						mvalue="i"+ctri;
		        						fi+=" "+ mvalue;
		        						map.putIfAbsent(mk,mvalue);
		        						load+="iload "+mvalue+" "+value+'\n';

		        					}
		        					else
		        					{
		        						mk=var[x];
		        						mvalue="i"+ctri;
		        						fi+=" "+ mvalue;
		        						map.putIfAbsent(mk,mvalue);
		        					}
		        					ctri++;

		        			}
		        			fi+=""+'\n'+load;
		        			
		        			break;
		        	}

		        	else if(ar[i].equals("float"))
		        	{
		        		ar[i]="f_store";
		        		fi=ar[i];
		        			i++;
		        			
		        			var=ar[i].split("[,;]");
		        			//System.out.println(Arrays.toString(var));
		        			for(int x=0;x<var.length;x++)
		        			{
		        					if(var[x].contains("="))
		        					{
		        						mk=var[x].substring(0,var[x].indexOf('='));
		        						value= var[x].substring(var[x].indexOf('=')+1);
		        						mvalue="f"+ctri;
		        						fi+=" "+ mvalue;
		        						map.putIfAbsent(mk,mvalue);
		        						load+="fload "+mvalue+" "+value+'\n';

		        					}
		        					else
		        					{
		        						mk=var[x];
		        						mvalue="f"+ctrf;
		        						fi+=" "+ mvalue;
		        						map.putIfAbsent(mk,mvalue);
		        					}
		        					ctrf++;

		        			}
		        			fi+=""+'\n'+load;
		        		break;
		        	}
		        	else if((ar[i].contains("new")||ar[i].equals("String"))&&!(ar[i].contains("contains")))
		        		{
		        			i++;
		        			
		        			
		        			
		        			var=ar[i].split("[,;]");
		        			//System.out.println(Arrays.toString(var));
		        			for(int x=0;x<var.length;x++)
		        			{
		        					if(var[x].contains("="))
		        					{
		        						mk=var[x].substring(0,var[x].indexOf('='));
		        						value= var[x].substring(var[x].indexOf('=')+1);
		        						mvalue="A"+ctro+"_store";
		        						fi=mvalue;
		        						map.putIfAbsent(mk,mvalue);
		        						load+=mvalue+" "+value+'\n';

		        					}
		        					else
		        					{
		        						mk=var[x];
		        						mvalue="A"+ctro+"_store";
		        						fi=mvalue;
		        						map.putIfAbsent(mk,mvalue);
		        					}
		        					ctro++;

		        			}
		        			if(!load.equals(""))
		        				fi+=""+'\n'+load;
		        		break;
		        			
		        		}
		        	else if(ar[i].contains(");")&&!str.contains("abstract")&&!str.contains("while"))
		        		{fi="invoke_special: "+str;break;}
		        	else if(ar[i].contains("){")&&!str.contains("for(")&&!str.contains("while("))
		        		{fi="Function:" +str;break;}
		        	else if(ar[i].contains("="))
		        	{
		        		if(map.containsKey(ar[i].substring(0,ar[i].indexOf('='))))
		        		{
		        						value= ar[i].substring(ar[i].indexOf('=')+1,ar[i].length()-1);
		        						//System.out.println(map);
		        						if(map.containsKey(value))
		        							value=map.get(value);
		        						mvalue=map.get((ar[i]).substring(0,ar[i].indexOf('=')));
		        						if(mvalue.charAt(0)=='i')
		        							fi="iload "+mvalue+" "+value;
		        						else if(mvalue.charAt(0)=='f')
		        							fi="fload "+mvalue+" "+value;
		        						else if(mvalue.charAt(0)=='A')
		        							fi=mvalue.substring(0,2)+"_load "+" "+value;
		        		}
		        		// else
		        		// 	throw new Exception("Variable not declared");

		        	}
		        	
		        }

		        if(fi=="")
		        {
		        	for(String st:ar)
		        	{
		        		fi+=st+" ";
		        	}
		        }
		        return fi;
	}
	public static keyword getInstance()
    {
        return new keyword();
    }
}