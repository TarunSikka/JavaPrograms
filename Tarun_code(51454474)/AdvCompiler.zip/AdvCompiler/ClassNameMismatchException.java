class ClassNameMismatchException extends Exception
{
	public ClassNameMismatchException()
	{
		System.out.println("Class & File name Not Matching");
	}
}