import java.util.*;

public class pair {


		static int ptr=-1;
		static char arr[]=new char[1000];
		static boolean flag=true;
	public static void find(String st)throws BracketMismatchException {
		String str=st;
		List<Character> list=Arrays.asList(str.chars().mapToObj(c -> (char)c).toArray(Character[]::new));
		list.forEach((Character c)->{
			if(c=='{')
				arr[++ptr]=c;
			else if(c=='}'&&flag==true)
			{	if(ptr!=-1&&arr[ptr]=='{')
				{	arr[ptr]='\u0000';
					ptr--;
				}
				else
					{
						flag=false;
						try{
							pair.check();
						}
						catch(BracketMismatchException e)
						{
							System.out.println("Mismatch");
						}
						
					}
			}
				
		});
		

	}
	public static void check()throws BracketMismatchException
	{
		if(ptr!=-1||flag==false)
			//System.out.println("Mismatch");
			throw new BracketMismatchException();
		// else
		// 	System.out.println("match");
	}
	public static pair getInstance()
	{
		return new pair();
	}

}