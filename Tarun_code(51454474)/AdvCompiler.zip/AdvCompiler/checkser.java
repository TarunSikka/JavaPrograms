import java.util.*;
public class checkser
    int a=5,b=6;
    float x,y;
    String sent;
    Consumer(){
        x=2.0;
        y=1.0;{
    }
    public void getRecord(){ 

                Consumer.getStudent();
                System.out.println("Name: "+st.getName());
                System.out.println("ID: "+st.getID());
                System.out.println("Marks: "+pd.map.get(st)+"\n");
    }

    public void getStudent(String name){
            a=b;
            x=4.0;
            sent="hello";
            for(int g=1;g<8;g++)
            {

            }
            Student stu=new Student();
                
                if(st.getName().equals(name))
                {
                    System.out.println("Found");
                    System.out.println("Name: "+st.getName());
                    System.out.println("ID: "+st.getID());
                    System.out.println("Marks: "+pd.map.get(st)+"\n");
                }
            
    }
}