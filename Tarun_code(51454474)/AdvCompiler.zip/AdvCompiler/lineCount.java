import java.util.*;
import java.io.*; 

public class lineCount extends myCompiler
{
@Override
public void convertForCount(File file)throws Exception
    {
            pair pr=pair.getInstance();
            keyword kc=keyword.getInstance(); 
            FileWriter to=new FileWriter(file.getName().replaceFirst("[.][^.]+$", "")+".class");
        
           try{
            Scanner sc = new Scanner(file); 
            while (sc.hasNextLine()) 
            {
                String str=sc.nextLine().trim();
                if(str.contains("public class")&&!(str.split(" ")[2].equals(file.getName().replaceFirst("[.][^.]+$", ""))))
                    throw new ClassNameMismatchException();
                // if(pr.flag==false)
                //     break;
                //String str=ar[i].trim();
                pr.find(str);
                str=kc.convertForKeyword(str);
                
                if(str.contains("){")&&!str.contains("for(")&&!str.contains("while("))
                {
                    to.write(str+"\n");
                    int ctr=0;
                    int ptr=0;
                    char arr[]=new char[1000];
                    arr[0]='{';
                    
                    while(ptr!=-1)
                    {
                        String sent=sc.nextLine().trim();
                        String reg="for\\(.+;.+;.+\\)";
                if(sent.contains("for("))
                {
                    if(sent.matches(reg))
                            sent="Loop: "+sent;
                    else
                        sent="Infinite loop: "+sent;
                        
                }
                if(sent.contains("while(true)"))    
                    sent="Infinite Loop: "+sent;
                else if(sent.contains("while("))
                    sent="Loop: "+sent;
                        
                        pr.find(sent);
                        String sent1=kc.convertForKeyword(sent);
                        for(char c:sent1.toCharArray())
                        {
                            if(c=='{')
                                arr[++ptr]=c;
                            else if(c=='}'&&ptr!=-1)
                            {       
                                arr[ptr]='\u0000';
                                ptr--;
                            }
                            
                        }
                        //System.out.println(ctr+""+sent1);
                        to.write(ctr+""+sent1+"\n");
                        ctr++;
                    }

                }
                else
                {
                    //System.out.println(str);
                    to.write(str+"\n");
                }
            }
            to.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println("No file exists");
        }
        pr.check();
        
    }
    public static lineCount getInstance()
    {
        return new lineCount();
    }
}