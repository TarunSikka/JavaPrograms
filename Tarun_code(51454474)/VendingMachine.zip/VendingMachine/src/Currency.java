
public abstract class Currency {
	public int amount;
	public abstract int value();
}
