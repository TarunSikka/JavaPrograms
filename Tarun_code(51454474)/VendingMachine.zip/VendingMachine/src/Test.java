import java.util.Scanner;


public class Test {
	public static void main(String[] args) {
		ConnectDatabase.connect();

		Scanner sc=new Scanner(System.in);
		System.out.println("passwordfd");
		int k=sc.nextInt();
		System.out.println("password");
		String p=sc.next();
		Admin a1=Admin.getInstance(p);
		switch(k)
		{
			case 1: System.out.println("view Balance");
					System.out.println("Balance---"+a1.getBalance());
					break;
			case 2: System.out.println("withdrawl");
					a1.withdrawl(100);
					break;
			case 3: System.out.println("deposit");
					a1.deposit(5000);
					break;
			case 4: System.out.println("Add items");
					System.out.println("Enter Tray code");
					String tCode=sc.next();
					System.out.println("Enter Product Name and Quantity");
					String pName=sc.next();
					int Quantity=sc.nextInt();
					a1.addItems(tCode,pName,Quantity);
					break;
			
		}
		
		
	}

}
